<?php

namespace Espo\Modules\Custom\Controllers;

class CProgram extends \Espo\Core\Templates\Controllers\Base
{}
