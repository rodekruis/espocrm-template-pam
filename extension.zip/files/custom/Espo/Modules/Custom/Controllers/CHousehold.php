<?php

namespace Espo\Modules\Custom\Controllers;

class CHousehold extends \Espo\Core\Templates\Controllers\Base
{}
