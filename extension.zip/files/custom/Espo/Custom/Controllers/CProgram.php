<?php

namespace Espo\Custom\Controllers;

class CProgram extends \Espo\Core\Templates\Controllers\BasePlus
{
}
