<?php

namespace Espo\Custom\Controllers;

class CCUser extends \Espo\Core\Templates\Controllers\Person
{
}
